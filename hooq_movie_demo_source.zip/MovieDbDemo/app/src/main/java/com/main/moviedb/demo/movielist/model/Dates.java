package com.main.moviedb.demo.movielist.model;

public class Dates{
	private String maximum;
	private String minimum;
}
