package com.main.moviedb.demo.moviedetails.model;

import java.util.List;

public class MovieDetailsList {

    private List<MovieDetails> movieDetailsList;

    public List<MovieDetails> getMovieDetailsList() {
        return movieDetailsList;
    }

    public void setMovieDetailsList(List<MovieDetails> movieDetailsList) {
        this.movieDetailsList = movieDetailsList;
    }
}
