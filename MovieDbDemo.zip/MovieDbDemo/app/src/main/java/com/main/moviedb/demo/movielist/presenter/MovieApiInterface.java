package com.main.moviedb.demo.movielist.presenter;

public interface MovieApiInterface {
    void onSuccessCallBack(String response);
}
